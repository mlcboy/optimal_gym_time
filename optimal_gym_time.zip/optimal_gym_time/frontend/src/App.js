import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import ChartComponent from './components/ChartComponent';
import FormComponent from './components/FormComponent';
import MEQForm from './components/MEQForm';
import { updateChartData } from './utils/updateChartData';
import './App.css';

const App = () => {
  const [day, setDay] = useState(1);
  const [wakeUpTime, setWakeUpTime] = useState(7);
  const [drinkCaffeine, setDrinkCaffeine] = useState(true);
  const [crowdednessWeight, setCrowdednessWeight] = useState(0.2);
  const [chronotype, setChronotype] = useState("intermediate");
  const [dataChart, setDataChart] = useState({});
  const [mealType, setMealType] = useState("carbs");
  const [mealTime, setMealTime] = useState(1);
  const [optimalTime, setOptimalTime] = useState("");

  const fetchData = async () => {
    const response = await fetch(`/optimal_gym_time?day=${day}&wake_up_time=${wakeUpTime}&drink_caffeine=${drinkCaffeine}&crowdedness_weight=${crowdednessWeight}&chronotype=${chronotype}`);
    const data = await response.json();
    updateChartData(data, wakeUpTime, drinkCaffeine, crowdednessWeight, setOptimalTime, setDataChart);
  };

  useEffect(() => {
    fetchData();
  }, [day, wakeUpTime, drinkCaffeine, crowdednessWeight, chronotype, mealType, mealTime]);


  const calculateScore = (answers) => {
    const score = answers.reduce((acc, curr) => acc + curr, 0);
    // Determine chronotype based on score
    if (score <= 41) {
      setChronotype('definite_evening');
    } else if (score <= 59) {
      setChronotype('moderate_evening');
    } else if (score <= 70) {
      setChronotype('intermediate');
    } else if (score <= 86) {
      setChronotype('moderate_morning');
    } else {
      setChronotype('definite_morning');
    }
  };

  return (
    <Router>
      <div className="app-container">
        {/* <nav className='navbar'>
          <ul className='nav-list'>
            <li className='nav-item'><Link to="/">Home</Link></li>
            <li className='nav-item'><Link to="/meq">Take the MEQ</Link></li>
          </ul>
        </nav> */}
        <Routes>
          <Route path="/" element={
            <>
              <FormComponent
                day={day}
                setDay={setDay}
                wakeUpTime={wakeUpTime}
                setWakeUpTime={setWakeUpTime}
                drinkCaffeine={drinkCaffeine}
                setDrinkCaffeine={setDrinkCaffeine}
                crowdednessWeight={crowdednessWeight}
                setCrowdednessWeight={setCrowdednessWeight}
                chronotype={chronotype}
                setChronotype={setChronotype}
                optimalTime={optimalTime}
                mealType={mealType}
                setMealType={setMealType}
                mealTime={mealTime}
                setMealTime={setMealTime}
              />
              <ChartComponent dataChart={dataChart} />
            </>
          } />
          <Route path="/meq" element={<MEQForm calculateScore={calculateScore} />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
