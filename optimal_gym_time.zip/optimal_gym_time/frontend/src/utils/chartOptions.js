import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    Title,
    Tooltip,
    Legend,
    SubTitle
  } from 'chart.js';
  import annotationPlugin from 'chartjs-plugin-annotation';
  
  ChartJS.register(
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    Title,
    Tooltip,
    Legend,
    SubTitle,
    annotationPlugin
  );
  
  export const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top',
        display: true,
        labels: {
          color: '#dcdcdc'
        }
      },
      title: {
        display: true,
        text: 'Optimal Gym Time Calculation',
        padding: {
          top: 10,
          bottom: 30
        },
        color: '#dcdcdc',
        font: {
          size: 20
        }
      },
      annotation: {
        annotations: {}
      }
    },
    scales: {
      x: {
        title: {
          display: true,
          text: 'Hour of the Day',
          color: '#dcdcdc',
          font: {
            size: 16,
            weight: 'bold'
          }
        },
        ticks: {
          color: '#dcdcdc',
          font: {
            size: 14
          }
        }
      },
      y: {
        title: {
          display: true,
          text: 'Score',
          color: '#dcdcdc',
          font: {
            size: 16,
            weight: 'bold'
          }
        },
        ticks: {
          color: '#dcdcdc',
          font: {
            size: 14
          }
        }
      }
    }
  };
  