import { options } from './chartOptions';
import { convertToAmPm, optimalTimeConverter } from './timeUtils';

export const updateChartData = (
  data,
  wakeUpTime,
  drinkCaffeine,
  crowdednessWeight,
  setOptimalTime,
  setDataChart
) => {
  const weights = {
    chronotype: 0.4,
    wakeUpTime: 0.2,
    caffeine: 0.2,
    crowdedness: crowdednessWeight //uses weight set by slider on form
  };

  const labels = Array.from({ length: 24 }, (_, i) => {
    const hour = (wakeUpTime + i) % 24;
    return convertToAmPm(hour);
  });

  const datasets = [
    {
      label: 'Body Temperature Score',
      data: data.body_temp_scores.filter((_, i) => i % 6 === 0),
      borderColor: 'red',
      backgroundColor: 'rgba(255, 0, 0, 0.5)',
      pointRadius: 0,
      fill: false,
    },
    {
      label: 'Crowd Score',
      data: data.crowd_scores.filter((_, i) => i % 6 === 0),
      borderColor: 'green',
      backgroundColor: 'rgba(0, 255, 0, 0.5)',
      pointRadius: 0,
      fill: false,
    },
    {
      label: 'Final Score',
      data: data.final_scores.filter((_, i) => i % 6 === 0),
      borderColor: 'black',
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
      pointRadius: 0,
      fill: false,
    }
  ];

  if (drinkCaffeine) {
    datasets.splice(1, 0, {
      label: 'Caffeine Score',
      data: data.caffeine_scores.filter((_, i) => i % 6 === 0),
      borderColor: 'blue',
      backgroundColor: 'rgba(0, 0, 255, 0.5)',
      pointRadius: 0,
      fill: false,
    });
  }

  const weightedScores = data.final_scores.map((score, index) => {
    const bodyTempScore = data.body_temp_scores[index] * weights.chronotype;
    const crowdScore = data.crowd_scores[index] * weights.crowdedness;
    const caffeineScore = drinkCaffeine ? data.caffeine_scores[index] * weights.caffeine : 0;

    return bodyTempScore + crowdScore + caffeineScore;
  });

  const peakIndex = weightedScores.indexOf(Math.max(...weightedScores));
  const peakHourIndex = Math.floor(peakIndex / 6);
  const peakTime = data.times[peakIndex];
  const optimalHour = Math.floor((peakTime / 3600 + wakeUpTime) % 24);
  const optimalMinute = Math.floor((peakTime % 3600) / 60);
  const formattedOptimalTime = `${optimalTimeConverter(optimalHour, optimalMinute)}`

  setOptimalTime(formattedOptimalTime);

  const updatedOptions = {
    ...options,
    plugins: {
      ...options.plugins,
      annotation: {
        annotations: {
          peakTimeLine: {
            type: 'line',
            xMin: peakHourIndex,
            xMax: peakHourIndex,
            borderColor: 'purple',
            borderWidth: 2,
            borderDash: [6, 6],
            label: {
              content: `Peak Time: ${formattedOptimalTime}`,
              enabled: true,
              position: 'top',
              color: 'purple',
              backgroundColor: 'rgba(0,0,0,0.8)',
              padding: {
                top: 5,
                bottom: 5
              }
            }
          }
        }
      }
    }
  };

  setDataChart({
    labels: labels,
    datasets: datasets,
    options: updatedOptions
  });
};
